# File: EnigmaMachine.py

"""
This module is the starter file for the EnigmaMachine class.
"""

from pgl import GImage, GCompound
from EnigmaKey import EnigmaKey, EnigmaLamp, EnigmaRotor, applyPermutation
from EnigmaConstants import *
from invertKey import invertKey
# Class: EnigmaMachine

class EnigmaMachine():
    """
    This class is responsible for storing the data needed to simulate
    the Enigma machine.  If you need to maintain any state information
    that must be shared among different parts of this implementation,
    you should define that information as part of this class and
    provide the necessary getters, setters, and other methods needed
    to manage that information.
    """

    def __init__(self, gw):
        """
        The constructor for the EnigmaMachine class is responsible for
        initializing the graphics window along with the state variables
        that keep track of the machine's operation.
        """
        enigmaImage = GImage("images/EnigmaTopView.png")
        gw.add(enigmaImage)
        listKey = []
        listLamp = []
        listRotor = []
        self.listKey = listKey
        self.listLamp = listLamp
        self.listRotor = listRotor
        for i in range(26):
            letter = ALPHABET[i]
            x_k = KEY_LOCATIONS[i][0] - KEY_RADIUS - KEY_BORDER/2
            y_k = KEY_LOCATIONS[i][1] - KEY_RADIUS
            x_l = LAMP_LOCATIONS[i][0] - LAMP_RADIUS - KEY_BORDER/2
            y_l = LAMP_LOCATIONS[i][1] - LAMP_RADIUS
            listKey.append(EnigmaKey(letter))
            listLamp.append(EnigmaLamp(letter))
            gw.add(listKey[i], x_k, y_k)
            gw.add(listLamp[i], x_l, y_l)
        for i in range(3):
            rotor = EnigmaRotor()
            rotor.encryption = ROTOR_PERMUTATIONS[i]
            listRotor.append(rotor)
            x_r = ROTOR_LOCATIONS[i][0]
            y_r = ROTOR_LOCATIONS[i][1]
            gw.add(listRotor[i], x_r, y_r)
            
    def keyPressed(self, letter):
        index = ALPHABET.index(letter)
        if self.listRotor[2].advance():
           if self.listRotor[1].advance():
               self.listRotor[0].advance()
        offset1 = self.listRotor[2].offset
        permF = self.listRotor[2].encryption
        permM = self.listRotor[1].encryption
        permS = self.listRotor[0].encryption
        fIndex = applyPermutation(index, permF, offset1)
        offset2 = self.listRotor[1].offset
        mIndex = applyPermutation(fIndex, permM, offset2)
        offset3 = self.listRotor[0].offset
        sIndex = applyPermutation(mIndex, permS, offset3)
        rIndex = applyPermutation(sIndex, REFLECTOR_PERMUTATION, 0)
        newSindex = applyPermutation(rIndex, invertKey(permS), offset3)
        newMindex = applyPermutation(newSindex, invertKey(permM), offset2)
        newFindex = applyPermutation(newMindex, invertKey(permF), offset1)
        self.listLamp[newFindex].setState(True)
        
    def keyReleased(self, letter):
        """This code is different because it reducces the extent of bug in the original code posted on website.
        If you drag the mouse out of the key, it will keep the lamp lit until there's another key that hits the same lamp.
        What I did here is reduce the computation time for figuring out the key, and also, if you press ANY key, the dragged lamp
        would be unlit again"""
        for lamp in self.listLamp:
            lamp.setState(False)