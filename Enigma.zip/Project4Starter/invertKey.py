# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 15:06:47 2019

@author: VDSHAMI
"""
from string import ascii_uppercase

def invertKey(key):
    keyList = list(key.upper())
    alphabetList = list(ascii_uppercase)
    result = ""
    for ch in alphabetList:
        index = keyList.index(ch)
        result += alphabetList[index]
    return result