# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 12:51:40 2019

@author: VDSHAMI
"""
from pgl import GCompound, GOval, GLabel, GWindow, GRect
from EnigmaConstants import *


def applyPermutation(index, permutation, offset):
    nInd = (index + offset)%26
    letter = permutation[nInd]
    newInd = (ALPHABET.index(letter) - offset)%26
    return newInd
class EnigmaKey(GCompound):
    def __init__(self, letter):
        GCompound.__init__(self)
        OuterCircle = GOval(2*KEY_RADIUS, 2*KEY_RADIUS)
        InnerCircle = GOval(2*(KEY_RADIUS - KEY_BORDER), 2*(KEY_RADIUS - KEY_BORDER))
        OuterCircle.setFilled(True)
        OuterCircle.setFillColor(KEY_BORDER_COLOR)
        InnerCircle.setFilled(True)
        InnerCircle.setFillColor(KEY_BGCOLOR)
        self.add(OuterCircle)
        self.add(InnerCircle, KEY_BORDER, KEY_BORDER)
        label = GLabel(letter)
        label.setFont(KEY_FONT)
        label.setColor(KEY_UP_COLOR)
        self.label = label
        self.le = letter
        x = (KEY_RADIUS + KEY_BORDER)/2
        self.add(label, x, KEY_RADIUS + KEY_LABEL_DY)
    
    def mousedownAction(self, enigma):
        self.label.setColor(KEY_DOWN_COLOR)
        enigma.keyPressed(self.le)
        
    def mouseupAction(self, enigma):
        self.label.setColor(KEY_UP_COLOR)
        enigma.keyReleased(self.le)
        

class EnigmaLamp(GCompound):
    def __init__(self, letter):
        GCompound.__init__(self)
        OuterCircle = GOval(2*LAMP_RADIUS, 2*LAMP_RADIUS)
        InnerCircle = GOval(2*(LAMP_RADIUS - KEY_BORDER + 2), 2*(LAMP_RADIUS - KEY_BORDER + 2))
        OuterCircle.setFilled(True)
        OuterCircle.setFillColor(LAMP_BORDER_COLOR)
        InnerCircle.setFilled(True)
        InnerCircle.setFillColor(LAMP_BGCOLOR)
        self.add(OuterCircle)
        self.add(InnerCircle, KEY_BORDER - 2, KEY_BORDER - 2)
        label = GLabel(letter)
        label.setFont(LAMP_FONT)
        label.setColor(LAMP_OFF_COLOR)
        self.label = label
        x = (LAMP_RADIUS + KEY_BORDER - 2)/2
        self.add(label, x, LAMP_RADIUS + LAMP_LABEL_DY)
    
    def setState(self, state):
        if state:
            self.label.setColor(LAMP_ON_COLOR)
        else:
            self.label.setColor(LAMP_OFF_COLOR)
    
    def getState(self):
        return self.label.getColor() == LAMP_ON_COLOR
    
    
class EnigmaRotor(GCompound):
    def __init__(self):
        GCompound.__init__(self)
        self.encryption = ""
        Bground = GRect(ROTOR_WIDTH, ROTOR_HEIGHT)
        Bground.setFilled(True)
        Bground.setColor(ROTOR_BGCOLOR)
        offset = 0
        self.offset = offset
        letter = ALPHABET[self.offset]
        self.letter = letter
        label = GLabel(self.letter)
        label.setFont(ROTOR_FONT)
        ROTOR_LABEL_DX = -1*label.getWidth()/2
        label.setColor(ROTOR_COLOR)
        self.label = label
        self.add(Bground, -1*ROTOR_WIDTH/2, -ROTOR_HEIGHT/2)
        self.add(label, ROTOR_LABEL_DX, ROTOR_LABEL_DY)
        
    def clickAction(self, enigma):
        self.advance()
    
    def advance(self):
        check = False
        self.remove(self.label)
        self.offset = self.offset + 1
        if self.offset >= 26:
            check = True
            self.offset = self.offset % 26
        self.label = GLabel(ALPHABET[self.offset])
        self.label.setFont(ROTOR_FONT)
        self.label.setColor(ROTOR_COLOR)
        self.add(self.label, -1*self.label.getWidth()/2, ROTOR_LABEL_DY)
        return check
    
    
if __name__ == "__main__":
    
    gw = GWindow(1000, 500)
    gw.add(EnigmaKey("Q"), 500, 250)
    